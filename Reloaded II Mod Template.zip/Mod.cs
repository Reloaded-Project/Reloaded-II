﻿using Reloaded.Hooks.ReloadedII.Interfaces;
using Reloaded.Mod.Interfaces;

namespace $safeprojectname$;

/// <summary>
/// Your mod logic goes here.
/// </summary>
public class Mod
{
    public Mod(IReloadedHooks hooks, ILogger logger)
    {
        // TODO: Implement some mod logic    
    }
}